{
"debug": "false",
"editor": "false",
"apk_version": "15122615",
"remote_log": "false",
"server_list_path": "http://127.0.0.1:8081/list.php",
"check_apk": "false",
"check_apk_path": "http://127.0.0.1:8081/apkcheck",
"res_version": "2021004090734",
"cdn_path": "http://127.0.0.1:8081/xcqy_dev",
"download_apk_path": "http://127.0.0.1:8081/res/apk",
"first_cdn_path": "http://127.0.0.1:8081/xcqy_dev"
} 